function f=frob(A,B)
f=trace(A'*B); % Frobenius scalar product between matrices A and B
end