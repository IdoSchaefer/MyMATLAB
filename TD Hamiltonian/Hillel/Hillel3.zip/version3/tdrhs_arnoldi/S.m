function y=S(t)
global T
y=sin(pi*t/T)^2;