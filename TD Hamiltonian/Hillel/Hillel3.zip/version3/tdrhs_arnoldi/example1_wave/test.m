function test
global L
global x
global T
global matvecs
global mu
mu=.6;
L=pi;
matvecs=0;
n=32;
dx=2*L/n;
x=[-L:dx:L-dx]';
u=uexact(x,0);
ud=duexact(x,0);
u=[u;ud];
m1=11;
m2=5;
steps=14;
T=10;
dt=T/steps;
t=0;
ireal=1;
for k=1:steps
    u=tdrhs_newton(u,'matvec',t,dt,m1,m2,ireal);
    t=t+dt;
end
toc
ex=uexact(x,T);
plot(x,ex,'k')
hold on
plot(x,u(1:n,1),'r')
norm(ex-u(1:n,1))
matvecs

