function y=duexact(x,t)
y=10*cos(10*(x+t));