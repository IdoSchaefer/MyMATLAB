function y=uexact(x,t)
y=sin(10*(x+t));