function y=ff(t)
global w0
y=S(t)*cos(w0*t);