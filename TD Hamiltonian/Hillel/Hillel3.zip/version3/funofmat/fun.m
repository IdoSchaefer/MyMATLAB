function y=fun(z,t)
y=exp(z*t);
